#include "gfx/legato/generated/le_gen_assets.h"

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   15
 *****************************************************************************/

/*****************************************************************************
 * string table data
 * 
 * this table contains the raw character data for each string
 * 
 * unsigned short - number of indices in the table
 * unsigned short - number of languages in the table
 * 
 * index array (size = number of indices * number of languages
 * 
 * for each index in the array:
 *   unsigned byte - the font ID for the index
 *   unsigned byte[3] - the offset of the string codepoint data in
 *                      the table
 * 
 * string data is found by jumping to the index offset from the start
 * of the table
 * 
 * string data entry:
 *     unsigned short - length of the string in bytes (encoding dependent)
 *     codepoint data - the string data
 ****************************************************************************/

const uint8_t stringTable_data[188] =
{
    0x0F,0x00,0x01,0x00,0x01,0x40,0x00,0x00,0x01,0x4C,0x00,0x00,0x01,0x52,0x00,0x00,
    0x01,0x5C,0x00,0x00,0x01,0x62,0x00,0x00,0x01,0x68,0x00,0x00,0x01,0x70,0x00,0x00,
    0x01,0x78,0x00,0x00,0x01,0x80,0x00,0x00,0x01,0x86,0x00,0x00,0x01,0x90,0x00,0x00,
    0x01,0x96,0x00,0x00,0x01,0x9E,0x00,0x00,0x01,0xA8,0x00,0x00,0x01,0xB6,0x00,0x00,
    0x0A,0x00,0x53,0x6F,0x69,0x6C,0x20,0x4C,0x65,0x76,0x65,0x6C,0x04,0x00,0x57,0x61,
    0x72,0x6D,0x07,0x00,0x42,0x65,0x64,0x64,0x69,0x6E,0x67,0x00,0x04,0x00,0x57,0x6F,
    0x6F,0x6C,0x03,0x00,0x48,0x6F,0x74,0x00,0x06,0x00,0x53,0x70,0x6F,0x72,0x74,0x73,
    0x06,0x00,0x4E,0x6F,0x72,0x6D,0x61,0x6C,0x05,0x00,0x53,0x54,0x41,0x52,0x54,0x00,
    0x04,0x00,0x43,0x6F,0x6C,0x64,0x07,0x00,0x4F,0x70,0x74,0x69,0x6F,0x6E,0x73,0x00,
    0x04,0x00,0x48,0x69,0x67,0x68,0x06,0x00,0x4D,0x65,0x64,0x69,0x75,0x6D,0x07,0x00,
    0x50,0x72,0x6F,0x67,0x72,0x61,0x6D,0x00,0x0B,0x00,0x54,0x65,0x6D,0x70,0x65,0x72,
    0x61,0x74,0x75,0x72,0x65,0x00,0x03,0x00,0x4C,0x6F,0x77,0x00,
};

/* font asset pointer list */
leFont* fontList[2] =
{
    (leFont*)&NotoSans_Bold,
    (leFont*)&buttonFont,
};

const leStringTable stringTable =
{
    {
        LE_STREAM_LOCATION_ID_INTERNAL, // data location id
        (void*)stringTable_data, // data address pointer
        188, // data size
    },
    (void*)stringTable_data, // string table data
    fontList, // font lookup table
    LE_STRING_ENCODING_ASCII // encoding standard
};


// string list
leTableString string_soil;
leTableString string_WarmTemp;
leTableString string_BedProg;
leTableString string_WoolProg;
leTableString string_HotTemp;
leTableString string_SportsProg;
leTableString string_NormalProg;
leTableString string_Start;
leTableString string_ColdTemp;
leTableString string_options;
leTableString string_HighSoilLevel;
leTableString string_MediumSoilLevel;
leTableString string_program;
leTableString string_temperature;
leTableString string_LowSoilLevel;

void initializeStrings(void)
{
    leTableString_Constructor(&string_soil, stringID_soil);
    leTableString_Constructor(&string_WarmTemp, stringID_WarmTemp);
    leTableString_Constructor(&string_BedProg, stringID_BedProg);
    leTableString_Constructor(&string_WoolProg, stringID_WoolProg);
    leTableString_Constructor(&string_HotTemp, stringID_HotTemp);
    leTableString_Constructor(&string_SportsProg, stringID_SportsProg);
    leTableString_Constructor(&string_NormalProg, stringID_NormalProg);
    leTableString_Constructor(&string_Start, stringID_Start);
    leTableString_Constructor(&string_ColdTemp, stringID_ColdTemp);
    leTableString_Constructor(&string_options, stringID_options);
    leTableString_Constructor(&string_HighSoilLevel, stringID_HighSoilLevel);
    leTableString_Constructor(&string_MediumSoilLevel, stringID_MediumSoilLevel);
    leTableString_Constructor(&string_program, stringID_program);
    leTableString_Constructor(&string_temperature, stringID_temperature);
    leTableString_Constructor(&string_LowSoilLevel, stringID_LowSoilLevel);
}
